# backend/app.py

from flask import Flask, render_template, request, redirect, url_for
import pymysql
from pymysql.cursors import DictCursor

app = Flask(__name__, template_folder='../frontend/templates')

DB_CONFIG = {
    'host':     '127.0.0.1',
    'user':     'newuser',
    'password': 'flight123456',
    'db':       'flight_tracking',
    'cursorclass': DictCursor,
    'port':     3306
}



def get_db_connection():
    return pymysql.connect(**DB_CONFIG)


# ─── Home ────────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')


# ─── AIRLINE ─────────────────────────────────────────────────────────────────────
@app.route('/airlines')
def airlines():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM airline;")
        data = cur.fetchall()
    return render_template('airlines.html', airlines=data)

@app.route('/airlines/add', methods=['POST'])
def add_airline():
    f = request.form
    sql = "INSERT INTO airline (airlineID, revenue) VALUES (%s,%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['airlineID'], f.get('revenue') or None))
        conn.commit()
    return redirect(url_for('airlines'))

@app.route('/airlines/edit/<aid>', methods=['GET','POST'])
def edit_airline(aid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = "UPDATE airline SET revenue=%s WHERE airlineID=%s;"
        with conn, conn.cursor() as cur:
            cur.execute(sql, (f.get('revenue') or None, aid))
            conn.commit()
        return redirect(url_for('airlines'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM airline WHERE airlineID=%s;", (aid,))
        rec = cur.fetchone()
    return render_template('edit_airline.html', airline=rec)

@app.route('/airlines/delete/<aid>', methods=['POST'])
def delete_airline(aid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM airline WHERE airlineID=%s;", (aid,))
        conn.commit()
    return redirect(url_for('airlines'))


# ─── AIRPLANE ───────────────────────────────────────────────────────────────────
@app.route('/airplanes')
def airplanes():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM airplane;")
        data = cur.fetchall()
    return render_template('airplanes.html', airplanes=data)

@app.route('/airplanes/add', methods=['POST'])
def add_airplane():
    f = request.form
    sql = """INSERT INTO airplane
          (airlineID, tail_num, seat_capacity, speed, locationID, plane_type, maintenanced, model, neo)
          VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s);"""
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (
            f['airlineID'], f['tail_num'], f['seat_capacity'], f['speed'],
            f.get('locationID') or None, f.get('plane_type') or None,
            f.get('maintenanced') or None, f.get('model') or None, f.get('neo') or None
        ))
        conn.commit()
    return redirect(url_for('airplanes'))

@app.route('/airplanes/edit/<airlineID>/<tail>', methods=['GET','POST'])
def edit_airplane(airlineID, tail):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE airplane
                 SET seat_capacity=%s, speed=%s, locationID=%s,
                     plane_type=%s, maintenanced=%s, model=%s, neo=%s
                 WHERE airlineID=%s AND tail_num=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (
              f['seat_capacity'], f['speed'], f.get('locationID') or None,
              f.get('plane_type') or None, f.get('maintenanced') or None,
              f.get('model') or None, f.get('neo') or None,
              airlineID, tail
            ))
            conn.commit()
        return redirect(url_for('airplanes'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM airplane WHERE airlineID=%s AND tail_num=%s;",
                    (airlineID, tail))
        rec = cur.fetchone()
    return render_template('edit_airplane.html', airplane=rec)

@app.route('/airplanes/delete/<airlineID>/<tail>', methods=['POST'])
def delete_airplane(airlineID, tail):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM airplane WHERE airlineID=%s AND tail_num=%s;",
                    (airlineID, tail))
        conn.commit()
    return redirect(url_for('airplanes'))


# ─── AIRPORT ────────────────────────────────────────────────────────────────────
@app.route('/airports')
def airports():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM airport;")
        data = cur.fetchall()
    return render_template('airports.html', airports=data)

@app.route('/airports/add', methods=['POST'])
def add_airport():
    f = request.form
    sql = """INSERT INTO airport
          (airportID, airport_name, city, state, country, locationID)
          VALUES (%s,%s,%s,%s,%s,%s);"""
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (
          f['airportID'], f.get('airport_name') or None,
          f['city'], f['state'], f['country'], f.get('locationID') or None
        ))
        conn.commit()
    return redirect(url_for('airports'))

@app.route('/airports/edit/<aid>', methods=['GET','POST'])
def edit_airport(aid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE airport
                 SET airport_name=%s, city=%s, state=%s, country=%s, locationID=%s
                 WHERE airportID=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (
                f.get('airport_name') or None,
                f['city'], f['state'], f['country'], f.get('locationID') or None,
                aid
            ))
            conn.commit()
        return redirect(url_for('airports'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM airport WHERE airportID=%s;", (aid,))
        rec = cur.fetchone()
    return render_template('edit_airport.html', airport=rec)

@app.route('/airports/delete/<aid>', methods=['POST'])
def delete_airport(aid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM airport WHERE airportID=%s;", (aid,))
        conn.commit()
    return redirect(url_for('airports'))


# ─── FLIGHT ─────────────────────────────────────────────────────────────────────
@app.route('/flights')
def flights():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM flight;")
        data = cur.fetchall()
    return render_template('flights.html', flights=data)

@app.route('/flights/add', methods=['POST'])
def add_flight():
    f = request.form
    sql = """INSERT INTO flight
          (flightID, routeID, support_airline, support_tail,
           progress, airplane_status, next_time, cost)
          VALUES (%s,%s,%s,%s,%s,%s,%s,%s);"""
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (
          f['flightID'], f['routeID'], f.get('support_airline') or None,
          f.get('support_tail') or None, f.get('progress') or None,
          f.get('airplane_status') or None, f.get('next_time') or None,
          f.get('cost') or 0
        ))
        conn.commit()
    return redirect(url_for('flights'))

@app.route('/flights/edit/<fid>', methods=['GET','POST'])
def edit_flight(fid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE flight
                 SET routeID=%s, support_airline=%s, support_tail=%s,
                     progress=%s, airplane_status=%s, next_time=%s, cost=%s
                 WHERE flightID=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (
             f['routeID'], f.get('support_airline') or None,
             f.get('support_tail') or None, f.get('progress') or None,
             f.get('airplane_status') or None, f.get('next_time') or None,
             f.get('cost') or 0, fid
            ))
            conn.commit()
        return redirect(url_for('flights'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM flight WHERE flightID=%s;", (fid,))
        rec = cur.fetchone()
    return render_template('edit_flight.html', flight=rec)

@app.route('/flights/delete/<fid>', methods=['POST'])
def delete_flight(fid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM flight WHERE flightID=%s;", (fid,))
        conn.commit()
    return redirect(url_for('flights'))


# ─── LEG ────────────────────────────────────────────────────────────────────────
@app.route('/legs')
def legs():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM leg;")
        data = cur.fetchall()
    return render_template('legs.html', legs=data)

@app.route('/legs/add', methods=['POST'])
def add_leg():
    f = request.form
    sql = "INSERT INTO leg (legID, departure, arrival, distance) VALUES (%s,%s,%s,%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['legID'], f['departure'], f['arrival'], f['distance']))
        conn.commit()
    return redirect(url_for('legs'))

@app.route('/legs/edit/<lid>', methods=['GET','POST'])
def edit_leg(lid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE leg
                 SET departure=%s, arrival=%s, distance=%s
                 WHERE legID=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (f['departure'], f['arrival'], f['distance'], lid))
            conn.commit()
        return redirect(url_for('legs'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM leg WHERE legID=%s;", (lid,))
        rec = cur.fetchone()
    return render_template('edit_leg.html', leg=rec)

@app.route('/legs/delete/<lid>', methods=['POST'])
def delete_leg(lid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM leg WHERE legID=%s;", (lid,))
        conn.commit()
    return redirect(url_for('legs'))


# ─── LOCATION ───────────────────────────────────────────────────────────────────
@app.route('/locations')
def locations():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM location;")
        data = cur.fetchall()
    return render_template('locations.html', locations=data)

@app.route('/locations/add', methods=['POST'])
def add_location():
    f = request.form
    sql = "INSERT INTO location (locationID) VALUES (%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['locationID'],))
        conn.commit()
    return redirect(url_for('locations'))

@app.route('/locations/delete/<lid>', methods=['POST'])
def delete_location(lid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM location WHERE locationID=%s;", (lid,))
        conn.commit()
    return redirect(url_for('locations'))


# ─── PERSON ─────────────────────────────────────────────────────────────────────
@app.route('/persons')
def persons():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM person;")
        data = cur.fetchall()
    return render_template('persons.html', persons=data)

@app.route('/persons/add', methods=['POST'])
def add_person():
    f = request.form
    sql = """INSERT INTO person
             (personID, first_name, last_name, locationID)
             VALUES (%s,%s,%s,%s);"""
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (
          f['personID'], f['first_name'],
          f.get('last_name') or None, f['locationID']
        ))
        conn.commit()
    return redirect(url_for('persons'))

@app.route('/persons/edit/<pid>', methods=['GET','POST'])
def edit_person(pid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE person
                 SET first_name=%s, last_name=%s, locationID=%s
                 WHERE personID=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (
              f['first_name'], f.get('last_name') or None,
              f['locationID'], pid
            ))
            conn.commit()
        return redirect(url_for('persons'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM person WHERE personID=%s;", (pid,))
        rec = cur.fetchone()
    return render_template('edit_person.html', person=rec)

@app.route('/persons/delete/<pid>', methods=['POST'])
def delete_person(pid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM person WHERE personID=%s;", (pid,))
        conn.commit()
    return redirect(url_for('persons'))


# ─── PASSENGER ──────────────────────────────────────────────────────────────────
@app.route('/passengers')
def passengers():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM passenger;")
        data = cur.fetchall()
    return render_template('passengers.html', passengers=data)

@app.route('/passengers/add', methods=['POST'])
def add_passenger():
    f = request.form
    sql = "INSERT INTO passenger (personID, miles, funds) VALUES (%s,%s,%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (
          f['personID'], f.get('miles') or 0, f.get('funds') or 0
        ))
        conn.commit()
    return redirect(url_for('passengers'))

@app.route('/passengers/edit/<pid>', methods=['GET','POST'])
def edit_passenger(pid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = "UPDATE passenger SET miles=%s, funds=%s WHERE personID=%s;"
        with conn, conn.cursor() as cur:
            cur.execute(sql, (f.get('miles') or 0, f.get('funds') or 0, pid))
            conn.commit()
        return redirect(url_for('passengers'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM passenger WHERE personID=%s;", (pid,))
        rec = cur.fetchone()
    return render_template('edit_passenger.html', passenger=rec)

@app.route('/passengers/delete/<pid>', methods=['POST'])
def delete_passenger(pid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM passenger WHERE personID=%s;", (pid,))
        conn.commit()
    return redirect(url_for('passengers'))


# ─── VACATIONS (passenger_vacations) ─────────────────────────────────────────────
@app.route('/vacations')
def vacations():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM passenger_vacations;")
        data = cur.fetchall()
    return render_template('vacations.html', vacations=data)

@app.route('/vacations/add', methods=['POST'])
def add_vacation():
    f = request.form
    sql = """INSERT INTO passenger_vacations
             (personID, airportID, sequence)
             VALUES (%s,%s,%s);"""
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['personID'], f['airportID'], f['sequence']))
        conn.commit()
    return redirect(url_for('vacations'))

@app.route('/vacations/edit/<pid>/<int:seq>', methods=['GET','POST'])
def edit_vacation(pid, seq):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE passenger_vacations
                 SET airportID=%s, sequence=%s
                 WHERE personID=%s AND sequence=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (
              f['airportID'], f['sequence'], pid, seq
            ))
            conn.commit()
        return redirect(url_for('vacations'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM passenger_vacations WHERE personID=%s AND sequence=%s;",
                    (pid, seq))
        rec = cur.fetchone()
    return render_template('edit_vacation.html', vac=rec)

@app.route('/vacations/delete/<pid>/<int:seq>', methods=['POST'])
def delete_vacation(pid, seq):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM passenger_vacations WHERE personID=%s AND sequence=%s;",
                    (pid, seq))
        conn.commit()
    return redirect(url_for('vacations'))


# ─── PILOT ───────────────────────────────────────────────────────────────────────
@app.route('/pilots')
def pilots():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM pilot;")
        data = cur.fetchall()
    return render_template('pilots.html', pilots=data)

@app.route('/pilots/add', methods=['POST'])
def add_pilot():
    f = request.form
    sql = """INSERT INTO pilot (personID, taxID, experience, commanding_flight)
             VALUES (%s,%s,%s,%s);"""
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (
          f['personID'], f['taxID'], f.get('experience') or 0, f.get('commanding_flight') or None
        ))
        conn.commit()
    return redirect(url_for('pilots'))

@app.route('/pilots/edit/<pid>', methods=['GET','POST'])
def edit_pilot(pid):
    conn = get_db_connection()
    if request.method=='POST':
        f = request.form
        sql = """UPDATE pilot
                 SET taxID=%s, experience=%s, commanding_flight=%s
                 WHERE personID=%s;"""
        with conn, conn.cursor() as cur:
            cur.execute(sql, (
              f['taxID'], f.get('experience') or 0, f.get('commanding_flight') or None, pid
            ))
            conn.commit()
        return redirect(url_for('pilots'))
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM pilot WHERE personID=%s;", (pid,))
        rec = cur.fetchone()
    return render_template('edit_pilot.html', pilot=rec)

@app.route('/pilots/delete/<pid>', methods=['POST'])
def delete_pilot(pid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM pilot WHERE personID=%s;", (pid,))
        conn.commit()
    return redirect(url_for('pilots'))


# ─── LICENSES (pilot_licenses) ──────────────────────────────────────────────────
@app.route('/licenses')
def licenses():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM pilot_licenses;")
        data = cur.fetchall()
    return render_template('licenses.html', licenses=data)

@app.route('/licenses/add', methods=['POST'])
def add_license():
    f = request.form
    sql = "INSERT INTO pilot_licenses (personID, license) VALUES (%s,%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['personID'], f['license']))
        conn.commit()
    return redirect(url_for('licenses'))

@app.route('/licenses/delete/<pid>/<lic>', methods=['POST'])
def delete_license(pid, lic):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM pilot_licenses WHERE personID=%s AND license=%s;",
                    (pid, lic))
        conn.commit()
    return redirect(url_for('licenses'))


# ─── ROUTE ──────────────────────────────────────────────────────────────────────
@app.route('/routes')
def routes():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM route;")
        data = cur.fetchall()
    return render_template('routes.html', routes=data)

@app.route('/routes/add', methods=['POST'])
def add_route():
    f = request.form
    sql = "INSERT INTO route (routeID) VALUES (%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['routeID'],))
        conn.commit()
    return redirect(url_for('routes'))

@app.route('/routes/delete/<rid>', methods=['POST'])
def delete_route(rid):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM route WHERE routeID=%s;", (rid,))
        conn.commit()
    return redirect(url_for('routes'))


# ─── ROUTE_PATH ─────────────────────────────────────────────────────────────────
@app.route('/route_paths')
def route_paths():
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("SELECT * FROM route_path;")
        data = cur.fetchall()
    return render_template('route_paths.html', rps=data)

@app.route('/route_paths/add', methods=['POST'])
def add_route_path():
    f = request.form
    sql = "INSERT INTO route_path (routeID, legID, sequence) VALUES (%s,%s,%s);"
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute(sql, (f['routeID'], f['legID'], f['sequence']))
        conn.commit()
    return redirect(url_for('route_paths'))

@app.route('/route_paths/delete/<rid>/<leg>/<int:seq>', methods=['POST'])
def delete_route_path(rid, leg, seq):
    conn = get_db_connection()
    with conn, conn.cursor() as cur:
        cur.execute("DELETE FROM route_path WHERE routeID=%s AND legID=%s AND sequence=%s;",
                    (rid, leg, seq))
        conn.commit()
    return redirect(url_for('route_paths'))

if __name__ == "__main__":
    app.run(debug=True, port=5002)
