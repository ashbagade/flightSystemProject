# Database connection helper
