# Reservations SQL functions
