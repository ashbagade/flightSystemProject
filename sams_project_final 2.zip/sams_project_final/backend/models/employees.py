# Employees SQL functions
