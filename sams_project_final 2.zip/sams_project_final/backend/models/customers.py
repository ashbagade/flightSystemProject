# Customers SQL functions
