# Flights SQL functions
