# Airports SQL functions
